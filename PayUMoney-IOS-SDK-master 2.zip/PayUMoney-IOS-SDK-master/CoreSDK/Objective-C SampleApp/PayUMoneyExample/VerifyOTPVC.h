//
//  VerifyOTPVC.h
//  PayUMoneyExample
//
//  Created by Umang Arya on 11/21/17.
//  Copyright © 2017 PayU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VerifyOTPVC : UIViewController

@end
