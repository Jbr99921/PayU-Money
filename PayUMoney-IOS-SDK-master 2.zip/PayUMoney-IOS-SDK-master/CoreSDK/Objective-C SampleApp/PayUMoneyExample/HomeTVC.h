//
//  HomeTVC.h
//  PayUMoneyExample
//
//  Created by Umang Arya on 6/28/17.
//  Copyright © 2017 PayU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeTVC : UITableViewController

@end
