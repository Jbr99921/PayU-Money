//
//  main.m
//  PlugNPlayFrameworkExample
//
//  Created by Umang Arya on 8/21/17.
//  Copyright © 2017 PayU Payments Pvt Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
