//
//  AppDelegate.h
//  PlugNPlayFrameworkExample
//
//  Created by Umang Arya on 8/21/17.
//  Copyright © 2017 PayU Payments Pvt Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

